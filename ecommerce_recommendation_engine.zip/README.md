# 🛍️ AuraShop: E-Commerce Recommendation Engine using DBMS and Query Optimization Techniques

A modern, full-stack college project demonstrating the practical application of **Relational Database Management Systems (DBMS)**, **B-Tree Indexing**, **Query Optimization Plans**, and **Dynamic Recommendation Algorithms** built with Python Flask and SQLite.

---

## 📋 Table of Contents
1. [Project Overview](#-project-overview)
2. [Technology Stack](#-technology-stack)
3. [System Architecture & Database Schema](#-system-architecture--database-schema)
4. [Key Features](#-key-features)
5. [Query Optimization Techniques Demonstrated](#-query-optimization-techniques-demonstrated)
6. [Recommendation Engine Strategies](#-recommendation-engine-strategies)
7. [Step-by-Step Setup Guide (Windows / VS Code)](#-step-by-step-setup-guide-windows--vs-code)
8. [Demo Accounts](#-demo-accounts)
9. [Feature Testing Checklist](#-feature-testing-checklist)
10. [College Viva & Presentation Q&A Guide](#-college-viva--presentation-qa-guide)
11. [Future Enhancements](#-future-enhancements)

---

## 🎯 Project Overview
In large-scale e-commerce platforms, database performance and personalized item discovery are two foundational pillars. Unoptimized database queries lead to full table scans, high disk I/O, memory exhaustion, and slow page response times.

This project delivers:
1. **A responsive, modern e-commerce storefront** styled with a purple aesthetic, light lavender background, clean white cards, and smooth micro-interactions.
2. **A multi-strategy recommendation engine** that computes real-time recommendations using SQL queries without hardcoded values.
3. **A dedicated DBMS Query Optimization Dashboard** comparing unoptimized vs optimized queries with `EXPLAIN QUERY PLAN`, live microsecond execution timings, composite indexing analysis, and Cost-Based Optimizer (CBO) insights.

---

## 🛠 Technology Stack
- **Backend Framework:** Python 3.10+ / Flask 3.x
- **Database Management System:** SQLite3 (Relational, Foreign Key Enforced, B-Tree Indexes)
- **Security:** Werkzeug Security (`generate_password_hash`, `check_password_hash` with PBKDF2/SHA256)
- **Frontend / Templating:** HTML5, CSS3, Jinja2 Templates, Vanilla JavaScript
- **Theme Palette:** Deep Royal Purple (`#6a1b9a`), Light Lavender (`#f4effa`), Clean Card White (`#ffffff`)

---

## 🗄 System Architecture & Database Schema

The database utilizes a **3rd Normal Form (3NF)** relational schema with primary keys, foreign keys with cascading actions, and integrity constraints.

```
       +-----------------------+
       |         users         |
       +-----------------------+
       | user_id (PK)          |
       | full_name             |
       | email (UNIQUE)        |
       | password_hash         |
       | is_admin              |
       | created_at            |
       +-----------+-----------+
                   |
       +-----------+-------------------------+
       |                                     |
+------v------+                       +------v------+
|    cart     |                       |   orders    |
+-------------+                       +-------------+
| cart_id (PK)|                       | order_id(PK)|
| user_id (FK)|                       | user_id(FK) |
| product_id  |                       | total_amount|
| quantity    |                       | status      |
| added_at    |                       | order_date  |
+------+------+                       +------+------+
       |                                     |
       |         +---------------+           |
       |         |   products    |           |
       +-------->+---------------+<----------+
       |         | product_id(PK)|           |
       |         | name          |           |
       |         | category      |           |
       |         | price         |           |
       |         | rating        |           |
       |         | stock         |           |
       |         | description   |           |
       |         | image         |           |
       |         +-------+-------+           |
       |                 |                   |
+------v--------+        |            +------v--------+
| user_activity |<-------+            |  order_items  |
+---------------+                     +---------------+
| activity_id PK|                     | item_id (PK)  |
| user_id (FK)  |                     | order_id (FK) |
| product_id FK |                     | product_id(FK)|
| activity_type |                     | quantity      |
| timestamp     |                     | unit_price    |
+---------------+                     +---------------+
```

### Table Definitions & Constraints
1. **`users`**: Stores user authentication data. Passwords are encrypted; plain text is never stored.
2. **`products`**: Inventory catalog with category, price (`CHECK(price >= 0)`), rating (`CHECK(rating BETWEEN 0 AND 5)`), and stock (`CHECK(stock >= 0)`).
3. **`wishlist`**: User-isolated saved items with `UNIQUE(user_id, product_id)` to prevent duplicate entries.
4. **`cart`**: User-isolated persistent cart with `UNIQUE(user_id, product_id)` to prevent duplicate item entries.
5. **`orders`**: Order transaction headers with `payment_method`, `payment_status` (Paid, Pending, Failed), and `transaction_id`.
6. **`order_items`**: Line items for orders, preserving historical purchase prices.
7. **`payments`**: Audit ledger of all simulated payments, linking `order_id`, `user_id`, `amount`, `payment_method`, `payment_status`, `transaction_id`, and `payment_date`.
8. **`user_activity`**: Audit trail of user browsing and purchasing activity (`view`, `cart_add`, `wishlist_add`, `purchase`) to fuel personalized recommendations.

---

## ⚡ Query Optimization Techniques Demonstrated

### 1. B-Tree Indexes
- **Single-Column Indexes:**
  - `idx_category ON products(category)`
  - `idx_price ON products(price)`
  - `idx_rating ON products(rating)`
  - `idx_wishlist_user ON wishlist(user_id)`
  - `idx_cart_user ON cart(user_id)`
  - `idx_orders_user ON orders(user_id)`
  - `idx_payments_user ON payments(user_id)`
  - `idx_payments_txn ON payments(transaction_id)`
  - `idx_activity_user ON user_activity(user_id)`
  - `idx_activity_prod ON user_activity(product_id)`

### 2. Composite Indexes (Multi-Column)
- **`idx_product_category_rating ON products(category, rating DESC)`**:
  - Optimizes queries that filter by category and sort by rating.
  - **Key Benefit:** Returns rows in pre-sorted order, completely eliminating SQLite's `USE TEMP B-TREE FOR ORDER BY` pass!
- **`idx_product_category_price ON products(category, price ASC)`**:
  - Optimizes category filtering with budget price sorting.
- **`idx_activity_composite ON user_activity(user_id, activity_type, product_id)`**:
  - Accelerates personalization queries aggregating user history.

### 3. SARGable Conditions vs Non-SARGable Expressions
- **Non-SARGable:** `WHERE (price + 0) <= 2000` or `WHERE category LIKE '%Books%'` (disables index, forces scan).
- **SARGable:** `WHERE price <= ?` and `WHERE category = ?` (traverses B-Tree index directly in $O(\log N)$).

### 4. Parameterized SQL Queries
- Prepared statements with `?` placeholders prevent **SQL Injection** and enable SQLite to cache compiled query execution plans.

### 5. EXPLAIN QUERY PLAN Analysis
- Visualizes SQLite opcode execution:
  - `SCAN TABLE products`: Full sequential scan of all pages ($O(N)$).
  - `SEARCH TABLE products USING INDEX <name>`: Binary search traversal of B-Tree index ($O(\log N)$).

---

## 🧠 Recommendation Engine Strategies

1. **Same-Category Rating-Weighted Recommendations:**
   - Evaluated when viewing a product.
   - SQL Query: Retrieves top-rated items in the same category excluding the open product.
   - Badge: *"Top rated in [Category]"*.
2. **User Browsing History Personalization:**
   - Evaluated on Homepage and Cart.
   - Analyzes recent views in `user_activity` to discover the user's primary category of interest.
   - Badge: *"Recommended because you browsed [Category]"*.
3. **Bestsellers & Popular Items (Sales Activity):**
   - Aggregates quantity ordered from `order_items` joined with `products`.
   - Badge: *"🔥 Trending Bestseller"*.
4. **Complementary Cross-Selling:**
   - Evaluated on Cart page.
   - Recommends top-rated additions excluding products already in cart.
   - Badge: *"✨ Popular addition to complete your order"*.

---

## 🚀 Step-by-Step Setup Guide (Windows / VS Code)

### Prerequisites
- Python 3.10 or newer installed on your Windows machine.
- Visual Studio Code (or any code editor).

### Step 1: Open the Project in VS Code
1. Launch **VS Code**.
2. Go to **File > Open Folder...** and select `ecommerce_recommendation_engine`.

### Step 2: Open the Integrated Terminal
- Press ``Ctrl + ` `` (Backtick) or go to **Terminal > New Terminal**.

### Step 3: (Recommended) Create & Activate Virtual Environment
In PowerShell:
```powershell
py -m venv .venv
.venv\Scripts\activate
```

### Step 4: Install Required Packages
```powershell
pip install -r requirements.txt
```

### Step 5: Initialize the Database (Auto-Run)
The database initializes automatically on first run. If you wish to initialize manually:
```powershell
py database.py
```

### Step 6: Run the Flask Application
```powershell
py app.py
```
You will see output in the terminal:
```
============================================================
 🛍️  E-Commerce Recommendation Engine Starting...
 Access URL: http://127.0.0.1:5000
 Demo User:  alex@college.edu  / Password: user123
 Admin User: admin@ecommerce.com / Password: admin123
============================================================
```

### Step 7: Open in Web Browser
Open your browser and navigate to:
[http://127.0.0.1:5000](http://127.0.0.1:5000)

---

## 🔑 Demo Accounts

| Role | Email Address | Password | Privileges |
|---|---|---|---|
| **Regular Student** | `alex@college.edu` | `user123` | Browsing, personalized recommendations, personal cart, order history |
| **Administrator** | `admin@ecommerce.com` | `admin123` | Product catalog management, add/edit/delete products, inventory stock adjustments |

*(You can also register any new account freely via the **Register** page!)*

---

## 🧪 Feature Testing Checklist

Run our comprehensive automated verification script anytime:
```powershell
py test_app.py
```

### Manual Testing Walkthrough:
- [x] **User Registration:** Navigate to `/register`. Register a new account. Try registering with the same email to confirm duplicate email detection.
- [x] **Secure Login & Logout:** Navigate to `/login`. Sign in using `alex@college.edu` / `user123`. Verify session name appears in navbar. Click Logout.
- [x] **Search & Category Filtering:** On Homepage, search for "Laptop" or select "Books". Use the price sliders.
- [x] **Dynamic Recommendations:** Click on "UltraBook Pro Laptop". Check the "Recommended Products" section below to see top-rated Electronics items with reason badges.
- [x] **Shopping Cart & Stock Limitation:** Add 2 units of an item. Visit `/cart`. Try increasing beyond available stock. Test remove button.
- [x] **Checkout Simulation:** Click "Proceed to Checkout". Verify order success screen, stock reduction in database, and record in `/orders`.
- [x] **Query Optimization Dashboard:** Navigate to `/optimization`. Observe the 4 side-by-side SQL scenarios, measured execution times, and index plans. Click *"Populate 5,000 Records Benchmark Dataset"* to demonstrate index scaling for examiners!
- [x] **Admin Dashboard:** Log in as `admin@ecommerce.com` / `admin123`. Visit `/admin`. Add a product, adjust stock, and edit details.

---

## 🎓 College Viva & Presentation Q&A Guide

### Q1: What is the main objective of this project?
> **Answer:** To demonstrate how relational database design, indexing techniques, and query optimization impact performance in an e-commerce recommendation system. We prove that using composite indexes and SARGable queries eliminates temporary sorting tables and full table scans.

### Q2: What is the difference between a Table Scan and an Index Search in SQLite?
> **Answer:**
> - **Table Scan (`SCAN TABLE`):** SQLite examines every row in the table sequentially from first to last ($O(N)$ complexity).
> - **Index Search (`SEARCH TABLE USING INDEX`):** SQLite traverses a balanced B-Tree index in $O(\log N)$ time to locate only the matching pointers.

### Q3: What is a Composite Index and why did you use it?
> **Answer:** A Composite Index indexes two or more columns together. We defined `idx_product_category_rating ON products(category, rating DESC)`. When searching by category ordered by rating, SQLite uses this index to both filter the category and fetch records in pre-sorted order, avoiding the expensive in-memory sort pass (`USE TEMP B-TREE FOR ORDER BY`).

### Q4: Why does SQLite sometimes perform a Table Scan even if an index exists?
> **Answer:** SQLite uses a **Cost-Based Optimizer (CBO)**. If a table has only 20 rows, the entire table fits into a single memory page (4KB). Scanning that single page in RAM is faster than loading an index page plus a data page. When the table grows into thousands of records, the CBO automatically switches to index lookups.

### Q5: How do Parameterized Queries protect the application?
> **Answer:** Parameterized queries (`?` placeholders) separate SQL code from user-supplied data. User inputs are treated strictly as literals, eliminating **SQL Injection**. Furthermore, database engines can cache and reuse the prepared execution plan for recurring queries.

---

## 🔮 Future Enhancements
1. **Collaborative Filtering:** Implement Matrix Factorization (SVD) or Cosine Similarity on user-item interaction vectors.
2. **Payment Gateway Integration:** Integrate Stripe or Razorpay sandbox for live test checkout.
3. **Database Migration to PostgreSQL:** Transition from SQLite to PostgreSQL with `EXPLAIN (ANALYZE, BUFFERS)` for enterprise deployment.
4. **Elasticsearch / Full-Text Search (FTS5):** Use SQLite FTS5 extension for fuzzy lexical searching and auto-completion.
